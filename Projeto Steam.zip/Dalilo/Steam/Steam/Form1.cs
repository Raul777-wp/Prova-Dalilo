﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string Usuario = "raullopol@hotmail.com";
            string Senha = "raul456";

            //txtusuario.Text = Usuario;
            //txtsenha.Text = Senha;

            if (txtusuario.Text.Equals(Usuario) && txtsenha.Text.Equals(Senha)){

           

                Form2 Loja = new Form2();
                Loja.Show();

            }
            else
            {

                  MessageBox.Show("Erro ao Conectar Tente Novamente.");

            }

          

        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
