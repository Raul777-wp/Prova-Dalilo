﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Steam
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

            MessageBox.Show(" FIFA 20 Adicionado na Sua Biblioteca");

        }

        private void Button2_Click(object sender, EventArgs e)
        {

            MessageBox.Show(" NBA 2K20 Adicionado na Sua Biblioteca");

        }

        private void Button3_Click(object sender, EventArgs e)
        {

            MessageBox.Show(" Watch Dogs Legion Adicionado na Sua Biblioteca");

        }

        private void Button4_Click(object sender, EventArgs e)
        {

            MessageBox.Show(" Ghost Reacon Adicionado na Sua Biblioteca");

        }

        private void Button5_Click(object sender, EventArgs e)
        {

            MessageBox.Show(" Call Of Duty Adicionado na Sua Biblioteca");

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}
