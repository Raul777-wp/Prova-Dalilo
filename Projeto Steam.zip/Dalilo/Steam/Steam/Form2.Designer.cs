﻿namespace Steam
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtbutton1 = new System.Windows.Forms.Button();
            this.txtbutton2 = new System.Windows.Forms.Button();
            this.txtbutton3 = new System.Windows.Forms.Button();
            this.txtbutton4 = new System.Windows.Forms.Button();
            this.txtbutton5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(1, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(496, 632);
            this.label1.TabIndex = 0;
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(494, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(554, 632);
            this.label2.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(1046, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(508, 632);
            this.label4.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(1553, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(502, 632);
            this.label5.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(2054, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(507, 632);
            this.label3.TabIndex = 9;
            // 
            // txtbutton1
            // 
            this.txtbutton1.Location = new System.Drawing.Point(4, 851);
            this.txtbutton1.Name = "txtbutton1";
            this.txtbutton1.Size = new System.Drawing.Size(493, 34);
            this.txtbutton1.TabIndex = 10;
            this.txtbutton1.Text = "Adicionar a Biblioteca";
            this.txtbutton1.UseVisualStyleBackColor = true;
            this.txtbutton1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // txtbutton2
            // 
            this.txtbutton2.Location = new System.Drawing.Point(497, 851);
            this.txtbutton2.Name = "txtbutton2";
            this.txtbutton2.Size = new System.Drawing.Size(551, 34);
            this.txtbutton2.TabIndex = 11;
            this.txtbutton2.Text = "Adicionar a Biblioteca";
            this.txtbutton2.UseVisualStyleBackColor = true;
            this.txtbutton2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // txtbutton3
            // 
            this.txtbutton3.Location = new System.Drawing.Point(1049, 851);
            this.txtbutton3.Name = "txtbutton3";
            this.txtbutton3.Size = new System.Drawing.Size(505, 34);
            this.txtbutton3.TabIndex = 12;
            this.txtbutton3.Text = "Adicionar a Biblioteca";
            this.txtbutton3.UseVisualStyleBackColor = true;
            this.txtbutton3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // txtbutton4
            // 
            this.txtbutton4.Location = new System.Drawing.Point(1556, 851);
            this.txtbutton4.Name = "txtbutton4";
            this.txtbutton4.Size = new System.Drawing.Size(495, 34);
            this.txtbutton4.TabIndex = 13;
            this.txtbutton4.Text = "Adicionar a Biblioteca";
            this.txtbutton4.UseVisualStyleBackColor = true;
            this.txtbutton4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // txtbutton5
            // 
            this.txtbutton5.Location = new System.Drawing.Point(2057, 851);
            this.txtbutton5.Name = "txtbutton5";
            this.txtbutton5.Size = new System.Drawing.Size(504, 34);
            this.txtbutton5.TabIndex = 14;
            this.txtbutton5.Text = "Adicionar a Biblioteca";
            this.txtbutton5.UseVisualStyleBackColor = true;
            this.txtbutton5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // Form2
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(2564, 961);
            this.Controls.Add(this.txtbutton5);
            this.Controls.Add(this.txtbutton4);
            this.Controls.Add(this.txtbutton3);
            this.Controls.Add(this.txtbutton2);
            this.Controls.Add(this.txtbutton1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button txtbutton1;
        private System.Windows.Forms.Button txtbutton2;
        private System.Windows.Forms.Button txtbutton3;
        private System.Windows.Forms.Button txtbutton4;
        private System.Windows.Forms.Button txtbutton5;
    }
}